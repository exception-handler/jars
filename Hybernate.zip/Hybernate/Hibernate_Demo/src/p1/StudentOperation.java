package p1;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;


public class StudentOperation {
	Session session;

	
	public StudentOperation() {
		
				// load cdg file
				Configuration cfg = new AnnotationConfiguration();
				// Session factory
				SessionFactory factory = cfg.configure().buildSessionFactory();
				// session
				session = factory.openSession();
	
	}
	

	public static void main(String[] args) {
		StudentOperation obj=new StudentOperation();
		obj.readStudent();
		
	}
	
	public void readStudent()
	{
		
		Transaction  t=session.beginTransaction();
		Student student=(Student)session.get(Student.class,2);
		System.out.println(student);
		t.commit();
	}
	
	public void updateStudent()
	{
		Transaction  t=session.beginTransaction();
		Student student=(Student)session.get(Student.class, 1);
		System.out.println(student);
		student.setLocation("NY");
		t.commit();
	}
	
	public void deleteStudent()
	{
		Transaction  t=session.beginTransaction();
		Student student=(Student)session.get(Student.class, 1);
		System.out.println(student);
		session.delete(student);
		t.commit();
	}
	public void getData()
	{
		Transaction  t=session.beginTransaction();
		List<Student> list=session.createQuery(" from Student").list();
		for (Student student : list) {
			System.out.println(student);
		}
	}
	
	public void finalize()
	{
		session.close();
	}
	
}
