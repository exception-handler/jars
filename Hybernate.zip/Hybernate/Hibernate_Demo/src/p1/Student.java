package p1;

import java.util.List;

import javax.jws.WebMethod;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.ws.soap.Addressing;

import org.hibernate.annotations.CollectionOfElements;

@Entity
@Table(name="MyStudent")
public class Student {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@Column(name="FirstName")
	private String name;
	private String location;
	private String course;
	@Embedded
	private Address address;
	@Embedded
	@AttributeOverrides({
		@AttributeOverride(name="streetNo",column=@Column(name="temp_streetNo")),
		@AttributeOverride(name="streetName",column=@Column(name="temp_streetName")),
	})
	private Address tempAddress;
	
	@CollectionOfElements
	private List<String> books;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Address getTempAddress() {
		return tempAddress;
	}

	public void setTempAddress(Address tempAddress) {
		this.tempAddress = tempAddress;
	}

	public List<String> getBooks() {
		return books;
	}

	public void setBooks(List<String> books) {
		this.books = books;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", location=" + location + ", course=" + course + ", address="
				+ address + ", tempAddress=" + tempAddress + ", books=" + books + "]";
	}

	public Student(String name, String location, String course, Address address, Address tempAddress,
			List<String> books) {
		super();
		this.name = name;
		this.location = location;
		this.course = course;
		this.address = address;
		this.tempAddress = tempAddress;
		this.books = books;
	}

	public Student(int id, String name, String location, String course, Address address, Address tempAddress,
			List<String> books) {
		super();
		this.id = id;
		this.name = name;
		this.location = location;
		this.course = course;
		this.address = address;
		this.tempAddress = tempAddress;
		this.books = books;
	}

	public Student(String name, String location, String course) {
		super();
		this.name = name;
		this.location = location;
		this.course = course;
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	
	
	
}
