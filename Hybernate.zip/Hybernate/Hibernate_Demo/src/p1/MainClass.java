package p1;

import java.awt.print.Book;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.hibernate.*;
import org.hibernate.cfg.*;

import oracle.net.TNSAddress.Address;

public class MainClass {
	// load cdg file
	Configuration cfg = new AnnotationConfiguration();
	// Session factory
	SessionFactory factory = cfg.configure().buildSessionFactory();
	// session
	Session session = factory.openSession();
	// transaction
	Transaction t = session.beginTransaction();
	// business operation
	Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {

		MainClass m = new MainClass();

		while (true) {
			System.out.println("enter choice:");
			System.out.println("1 to add");
			System.out.println("2 to find");
			System.out.println("3 to update");
			System.out.println("4 to delete");
			System.out.println("5 to see data according to course");
			System.out.println("6 to see all the data");
			System.out.println("0 to exit");
			int ch = Integer.parseInt(m.sc.nextLine());
			switch (ch) {
			case 1:
				m.addData();
				break;
			case 2:
				System.out.println("enter id");
				int id=Integer.parseInt(m.sc.nextLine());
				m.readStudent(id);
				break;
			case 3:
				m.updateStudent();
				break;
			case 4:
				m.deleteStudent();
				break;
			case 5:
				System.out.println("enter course");
				String course=m.sc.nextLine();
				m.getDataUsingCourse(course);
				break;
			case 6:
				m.getData();
				break;
			case 0:
				System.exit(0);

			default:
				System.out.println("Wrong choice");
				break;
			}// switch end

		} // while end

	}// main end

	public void addData(){
		
		List<String> list=new ArrayList<String>();
		list.add("JAVA");
		list.add("C++");
		Student s = new Student("name", "location", "course",
				new p1.Address(101, "streetName")
				, new p1.Address(102, "streetName"), list);
				session.save(s);
		t.commit();
		session.close();
	}
	public void add() {
		System.out.println("Enter name");
		String name = sc.nextLine();
		System.out.println("Enter location");
		String location = sc.nextLine();
		System.out.println("enter course");
		String course = sc.nextLine();
		Student s = new Student(name, location, course);
		session.save(s);
		// commit transasction
		t.commit();
		// session close
		session.close();
		System.out.println("........Data Saved..........");
	}
	
	public void readStudent(int id)
	{
		
		Transaction  t=session.beginTransaction();
		Student student=(Student)session.get(Student.class,id);
		System.out.println(student);
		t.commit();
	}
	
	public void updateStudent()
	{
		Transaction  t=session.beginTransaction();
		Student student=(Student)session.get(Student.class, 1);
		System.out.println(student);
		student.setLocation("Delhi");
		t.commit();
	}
	
	public void deleteStudent()
	{
		Transaction  t=session.beginTransaction();
		Student student=(Student)session.get(Student.class, 1);
		System.out.println(student);
		session.delete(student);
		t.commit();
	}
	
	public void getDataUsingCourse(String course)
	{
		Transaction  t=session.beginTransaction();
		List<Student> list=session.createQuery(" from Student where course='"+course+"'").list();
		for (Student student : list) {
			System.out.println(student);
		}
		t.commit();
	}
	
	public void getData()
	{
		Transaction  t=session.beginTransaction();
		List<Student> list=session.createQuery("from Student").list();//return type is list
		for (Student student : list) {
			System.out.println(student);
		}
		t.commit();
	}
	
	public void finalize()
	{
		session.close();
	}
	
}// class end
