package answer1;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class CreditCard extends Payment {

	
	private int creditCardNumber;
	
	private String bank;

	private String datert;
	public int getCreditCardNumber() {
		return creditCardNumber;
	}
	public void setCreditCardNumber(int creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
	public String getBank() {
		return bank;
	}
	public void setBank(String bank) {
		this.bank = bank;
	}
	public String getDate() {
		return datert;
	}
	public void setDate(String date) {
		this.datert = date;
	}
	@Override
	public String toString() {
		return "CreditCard [creditCardNumber=" + creditCardNumber + ", bank=" + bank + ", date=" + datert + "]";
	}
	public CreditCard(String custName, int custMobile, String custAddress, int creditCardNumber, String bank,
			String date) {
		super(custName, custMobile, custAddress);
		this.creditCardNumber = creditCardNumber;
		this.bank = bank;
		this.datert = date;
	}
	public CreditCard() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CreditCard(String custName, int custMobile, String custAddress) {
		super(custName, custMobile, custAddress);
		// TODO Auto-generated constructor stub
	}

	
}
