package answer1;

import javax.persistence.Entity;

@Entity
public class Cash extends Payment {

	private int totalAmount;
	private int paidAmount;
	public int getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}
	public int getPaidAmount() {
		return paidAmount;
	}
	public void setPaidAmount(int paidAmount) {
		this.paidAmount = paidAmount;
	}
	@Override
	public String toString() {
		return "Cash [totalAmount=" + totalAmount + ", paidAmount=" + paidAmount + "]";
	}
	public Cash(String custName, int custMobile, String custAddress, int totalAmount, int paidAmount) {
		super(custName, custMobile, custAddress);
		this.totalAmount = totalAmount;
		this.paidAmount = paidAmount;
	}
	public Cash() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Cash(String custName, int custMobile, String custAddress) {
		super(custName, custMobile, custAddress);
		// TODO Auto-generated constructor stub
	}
	
}
