package answer1;


import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;




public class Admin {
	
	Scanner sc=new Scanner(System.in);
	
		// load cdg file
		Configuration cfg = new AnnotationConfiguration();
		// Session factory
		SessionFactory factory = cfg.configure().buildSessionFactory();
		// session
		Session  session= factory.openSession();
		// transaction
		Transaction t = session.beginTransaction();
		// business operationS
	

	public static void main(String[] args) {
		
	Admin admin=new Admin();

	while (true) {
		System.out.println("enter choice:");
		System.out.println("1 to add");
		System.out.println("2 to search");
		System.out.println("3 to update");
		System.out.println("4 to delete");
		System.out.println("0 to exit");
		int ch = Integer.parseInt(admin.sc.nextLine());
		switch (ch) {
		case 1:
			admin.add();
			break;
		case 2:
			System.out.println("enter name to be searched:");
			String name=admin.sc.nextLine();
			admin.search(name);
			break;
		case 3:
			System.out.println("enter id to be updated:");
			int id=Integer.parseInt(admin.sc.nextLine());
			admin.update(id);
			break;
		case 4:
			System.out.println("enter id to be deleted:");
			int id1=Integer.parseInt(admin.sc.nextLine());
			admin.delete(id1);
			break;
		
		case 0:
			System.exit(0);

		default:
			System.out.println("Wrong choice");
			break;
		}// switch end

	} // while end

}
	
	public void add(){
		t=session.beginTransaction();
		System.out.println("Enter name");
		String name = sc.nextLine();
		Item item=new Item(name);
		session.save(item);
		t.commit();
		
		
	}

	public void search(String name){
		t=session.beginTransaction();
		List<Item> list=session.createQuery("from Item where name="+"\'"+name+"\'").list();
		for (Item item : list) {
			System.out.println(item);		
		}
		t.commit();
	
		
	}
	
	public void update(int id){
		t=session.beginTransaction();
		Item item=(Item)session.get(Item.class, id);
		System.out.println("Enter name to be updated");
		String name=sc.nextLine();
		item.setName(name);
		t.commit();
	}
	public void delete(int id){
		t=session.beginTransaction();
		Item item=(Item)session.get(Item.class, id);
		session.delete(item);
		t.commit();
	}
	public void finalize(){
		session.close();
	}
	
}
