package answer2;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class ProductDetails {
	Scanner sc=new Scanner(System.in);
	List<Product> list=new ArrayList<>();
	public static void main(String[] args) throws ParseException {
		ProductDetails p=new ProductDetails();
		p.addDetails();
	}

	public void addDetails() throws ParseException
	{
		
		System.out.println("How many product u want to insert");
		int count=Integer.parseInt(sc.nextLine());
		for (int i = 0; i < count; i++) {
			
			System.out.println("enter name");
			String productName=sc.nextLine();
		
			System.out.println("manuf date in yyyy-MM-dd");
			String manufDate=sc.nextLine();
			
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			
			Date date1=sdf.parse(manufDate);
			java.sql.Date manufDate1= new java.sql.Date(date1.getTime());
			
			System.out.println("enter exp date in yyyy-MM-dd");
			String expDate=sc.nextLine();
			
			Date date=sdf.parse(expDate);
			java.sql.Date expDate1= new java.sql.Date(date.getTime());
			
			System.out.println("enter price");
			float price=Float.parseFloat(sc.nextLine());
		
			Product product=new Product(productName, manufDate1, expDate1, price);
			list.add(product);
			
		}
		
		insertDetails(list);
		
	}
	
	public void insertDetails(List<Product> list)
	{
		Session session = HibernateUitl.util();
		Transaction t = session.beginTransaction();	
		for (Product product : list) {
			session.save(product);
		}
		t.commit();
	}
}
