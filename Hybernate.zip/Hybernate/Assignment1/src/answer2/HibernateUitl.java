package answer2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class HibernateUitl {
			public static Session util(){
				
				// load cdg file
				Configuration cfg = new AnnotationConfiguration();
				// Session factory
				SessionFactory factory = cfg.configure().buildSessionFactory();
				// session
				Session  session= factory.openSession();
				// transaction
				// business operationS
				
				return session;
			}
}
