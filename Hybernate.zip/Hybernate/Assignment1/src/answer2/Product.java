package answer2;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Product {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productId;
	private String productName;
	private Date manufDate;
	private Date expDate;
	private float price;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Date getManufDate() {
		return manufDate;
	}
	public void setManufDate(Date manufDate) {
		this.manufDate = manufDate;
	}
	public Date getExpDate() {
		return expDate;
	}
	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", manufDate=" + manufDate
				+ ", expDate=" + expDate + ", price=" + price + "]";
	}
	public Product(int productId, String productName, Date manufDate, Date expDate, float price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.manufDate = manufDate;
		this.expDate = expDate;
		this.price = price;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(String productName, Date manufDate, Date expDate, float price) {
		super();
		this.productName = productName;
		this.manufDate = manufDate;
		this.expDate = expDate;
		this.price = price;
	}

	
}
