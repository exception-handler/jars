package p1;

import javax.persistence.Entity;

@Entity
public class HatchBack extends Car {
	
	String space;

	public String getSpace() {
		return space;
	}

	public void setSpace(String space) {
		this.space = space;
	}

	@Override
	public String toString() {
		return "HatchBack [space=" + space + "]";
	}

	public HatchBack(String brand, String space) {
		super(brand);
		this.space = space;
	}

	public HatchBack() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HatchBack(String brand) {
		super(brand);
		// TODO Auto-generated constructor stub
	}
	
	

}
