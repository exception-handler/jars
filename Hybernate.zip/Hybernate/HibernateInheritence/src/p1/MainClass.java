package p1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class MainClass {
	Session session;
	Transaction t;
	public MainClass() {
		// load cdg file
		Configuration cfg = new AnnotationConfiguration();
		// Session factory
		SessionFactory factory = cfg.configure().buildSessionFactory();
		// session
		session = factory.openSession();
		// transaction
		t = session.beginTransaction();
		// business operation
	}
	
	public static void main(String[] args) {
		

		MainClass main=new MainClass();
		main.enterData();
	}
	
	public void enterData()
	{
		HatchBack hatch=new HatchBack("XUV", "LARGE");
		SportsCar sports=new SportsCar("BMW", 200);
		Car car= new Car("AUDI");
		session.save(car);
		session.save(hatch);
		session.save(sports);
		t.commit();
		System.out.println("---DONE---");
	}

}
