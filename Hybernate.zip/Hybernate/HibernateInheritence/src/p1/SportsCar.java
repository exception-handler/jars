package p1;

import javax.persistence.Entity;

@Entity
public class SportsCar extends Car {
	
	int speed;

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	@Override
	public String toString() {
		return "SportsCar [speed=" + speed + "]";
	}

	public SportsCar(String brand, int speed) {
		super(brand);
		this.speed = speed;
	}

	public SportsCar() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SportsCar(String brand) {
		super(brand);
		// TODO Auto-generated constructor stub
	}
	

}
