package p1;

import java.io.Serializable;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class MainClass {
Session session;
Transaction t;
	public MainClass() {
		// load cdg file
		Configuration cfg = new AnnotationConfiguration();
		// Session factory
		SessionFactory factory = cfg.configure().buildSessionFactory();
		// session
		session = factory.openSession();
		// transaction
		t = session.beginTransaction();
		// business operation
	}

	public static void main(String[] args) {
		
		System.out.println("Befor cfg");
	
		MainClass main=new MainClass();
/*		
		Student s=new Student("Mohit", new StudentBGV("infogain", true));
		session.save(s);
		Student s1=new Student("abhi", new StudentBGV("infosys", false));
		session.save(s1);
		Student s2=new Student("vipin", new StudentBGV("hcl", true));
		session.save(s2);*/
		/*Student stu=(Student) session.get(Student.class,1);
		System.out.println(stu);
		t.commit();
		session.close();
		System.out.println("----DONE-------");
		*/
			//main.addStudent();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id");
		int id=Integer.parseInt(sc.nextLine());
		main.readStudent(id);
	}

	public void readStudent(int id)
	{
		
		Transaction  t=session.beginTransaction();
		StudentBGV studentbgv=(StudentBGV)session.get(StudentBGV.class,id);
		System.out.println(studentbgv);
		
		t.commit();
	}
	
	public void addStudent()
	{
		Student s=new Student("abhishek", new StudentBGV("infogain", true));
		session.save(s);
		t.commit();
		System.out.println("----DONE-------");
	}
	public void finalize()
	{
		session.close();
	}
}
