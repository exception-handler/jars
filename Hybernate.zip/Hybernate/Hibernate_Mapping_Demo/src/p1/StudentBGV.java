package p1;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Cascade;
@Entity
public class StudentBGV {
	
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int recordID;
private String companyName;
private boolean isStatus;

@OneToOne(mappedBy="bgvDetails",cascade=CascadeType.ALL)
private Student student;


public Student getStudent() {
	return student;
}
public void setStudent(Student student) {
	this.student = student;
}
public int getRecordID() {
	return recordID;
}
public void setRecordID(int recordID) {
	this.recordID = recordID;
}
public String getCompanyName() {
	return companyName;
}
public void setCompanyName(String companyName) {
	this.companyName = companyName;
}
public boolean isStatus() {
	return isStatus;
}
public void setStatus(boolean isStatus) {
	this.isStatus = isStatus;
}

@Override
public String toString() {
	return "StudentBGV [recordID=" + recordID + ", companyName=" + companyName + ", isStatus=" + isStatus + ", student="
			+ student + "]";
}
public StudentBGV(int recordID, String companyName, boolean isStatus) {
	super();
	this.recordID = recordID;
	this.companyName = companyName;
	this.isStatus = isStatus;
}
public StudentBGV() {
	super();
	// TODO Auto-generated constructor stub
}
public StudentBGV(String companyName, boolean isStatus) {
	super();
	this.companyName = companyName;
	this.isStatus = isStatus;
}


}
