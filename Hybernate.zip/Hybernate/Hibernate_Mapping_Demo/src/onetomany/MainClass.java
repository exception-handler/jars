package onetomany;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class MainClass {
	Session session;
	Transaction t;
	List<Account> list=new ArrayList<>();
		public MainClass() {
			// load cdg file
			Configuration cfg = new AnnotationConfiguration();
			// Session factory
			SessionFactory factory = cfg.configure().buildSessionFactory();
			// session
			session = factory.openSession();
			// transaction
			t = session.beginTransaction();
			// business operation
		}
	public static void main(String[] args) {
		
		MainClass main=new MainClass();
		main.enterData();
		main.searchData();

	}
	
	public void enterData()
	{	
		
		list.add(new Account("savings"));
		list.add(new Account("Current"));
		Person person=new Person("Rohan", list);
		session.save(person);
		System.out.println("---DONE---");
		t.commit();
	}
	
	public void searchData()
	{
		
	}

}
