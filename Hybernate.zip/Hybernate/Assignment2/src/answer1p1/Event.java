package answer1p1;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.CollectionOfElements;

import answer1p2.FeedBack;

@Entity
public class Event {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String eventName;

	@CollectionOfElements
	private List<String> feedback;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public List<String> getFeedback() {
		return feedback;
	}

	public void setFeedback(List<String> feedback) {
		this.feedback = feedback;
	}

	public Event(String eventName, List<String> feedback) {
		super();
		this.eventName = eventName;
		this.feedback = feedback;
	}

	@Override
	public String toString() {
		return "Event [id=" + id + ", eventName=" + eventName + ", feedback=" + feedback + "]";
	}

	public Event() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
