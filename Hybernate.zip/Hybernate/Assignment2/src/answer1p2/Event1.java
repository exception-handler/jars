package answer1p2;

import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.CollectionOfElements;

@Entity
public class Event1 {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String eventName;
	
	@OneToMany(cascade=CascadeType.ALL)
	private List<FeedBack> feedback;
	
	@Override
	public String toString() {
		return "Event [id=" + id + ", eventName=" + eventName + ", feedback=" + feedback + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public List<FeedBack> getFeedback() {
		return feedback;
	}
	public void setFeedback(List<FeedBack> feedback) {
		this.feedback = feedback;
	}
	public Event1(String eventName, List<FeedBack> feedback) {
		super();
		this.eventName = eventName;
		this.feedback = feedback;
	}
	public Event1() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
