package answer1p2;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.From;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;



public class MainClass {
	Session session;
	Transaction t;
	List<FeedBack> list=new ArrayList<>();
		public MainClass() {
			// load cdg file
			Configuration cfg = new AnnotationConfiguration();
			// Session factory
			SessionFactory factory = cfg.configure().buildSessionFactory();
			// session
			session = factory.openSession();
			// transaction
			t = session.beginTransaction();
			// business operation
		}
		
		public static void main(String[] args) {
			
			MainClass main=new MainClass();
			main.addData();
			main.seeData();
		}
		
		
		public void addData()
		{
			list.add(new FeedBack("It was good"));
			list.add(new FeedBack("GOOD"));
			Event1 event=new Event1("WWF",list);
			session.save(event);
			t.commit();
			
		}
		
		public void seeData()
		{
			t=session.beginTransaction();
		List<Event1> e=session.createQuery("from Event1").list();
			for (Event1 event1 : e) {
				System.out.println(event1);
			}
			t.commit();	
		}
}
