package answer1p2;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class FeedBack {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String feedback;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	@Override
	public String toString() {
		return "FeedBack [id=" + id + ", feedback=" + feedback + "]";
	}
	public FeedBack() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FeedBack(String feedback) {
		super();
		this.feedback = feedback;
	}
	
	
	
}
